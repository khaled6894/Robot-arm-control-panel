<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
 
$host = "localhost";
$user = "root";
$pass = "";
$db   = "robot_arm";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("DB connection failed: " . $conn->connect_error);
}

$newStatus = isset($_GET['status']) ? (int)$_GET['status'] : 0;

$stmt = $conn->prepare("UPDATE run SET status = ?");
$stmt->bind_param("i", $newStatus);

if ($stmt->execute()) {
    echo "<h3>Record updated successfully</h3>";
} else {
    echo "Update failed: " . $conn->error;
}

$stmt->close();
$conn->close();