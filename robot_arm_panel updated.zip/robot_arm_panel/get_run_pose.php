<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);


$host = "localhost";
$user = "root";
$pass = "";
$db   = "robot_arm";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    header('Content-Type: text/plain');
    die("DB connection failed");
}


$sql = "SELECT id, servo1, servo2, servo3, servo4, servo5, servo6, status
    FROM run
    ORDER BY id DESC
    LIMIT 1";
$res = $conn->query($sql);

header('Content-Type: text/plain'); 

if ($res && $row = $res->fetch_assoc()) {
    
    echo $row['status']
    . ",s1" . $row['servo1']
    . ",s2" . $row['servo2']
    . ",s3" . $row['servo3']
    . ",s4" . $row['servo4']
    . ",s5" . $row['servo5']
    . ",s6" . $row['servo6'];
} else {
    echo "no_data"; 
}
$conn->close();