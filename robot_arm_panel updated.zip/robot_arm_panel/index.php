<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// اتصال بقاعدة البيانات
$host = "localhost";
$user = "root";
$pass = "";
$db = "robot_arm";
$conn = new mysqli($host, $user, $pass, $db);

// poseحفظ وضعية جديدة في جدول 
if (isset($_POST['save'])) {
$s1 = $_POST['servo1'];
$s2 = $_POST['servo2'];
$s3 = $_POST['servo3'];
$s4 = $_POST['servo4'];
$s5 = $_POST['servo5'];
$s6 = $_POST['servo6'];

$stmt = $conn->prepare("INSERT INTO pose (servo1, servo2, servo3, servo4, servo5, servo6) VALUES (?,?,?,?,?,?)");
$stmt->bind_param("iiiiii", $s1, $s2, $s3, $s4, $s5, $s6);
$stmt->execute();
$stmt->close();
header("Location: ".$_SERVER['PHP_SELF']);
exit();
}

// (status=0تغيير )حذف وضعية 
if (isset($_POST['remove'])) {
$id = $_POST['id'];
$stmt = $conn->prepare("UPDATE pose SET status=0 WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->close();
header("Location: ".$_SERVER['PHP_SELF']);
exit();
}

// runتشغيل وضعية: حفظ القيم بجدول 
if (isset($_POST['run'])) {
$s1 = $_POST['servo1'];
$s2 = $_POST['servo2'];
$s3 = $_POST['servo3'];
$s4 = $_POST['servo4'];
$s5 = $_POST['servo5'];
$s6 = $_POST['servo6'];

// runنحذف القيم القديمة من جدول 
$conn->query("DELETE FROM run");

// نضيف الوضعية الجديدة
$stmt = $conn->prepare("INSERT INTO run (servo1, servo2, servo3, servo4, servo5, servo6, status) VALUES (?,?,?,?,?,?,1)");
$stmt->bind_param("iiiiii", $s1, $s2, $s3, $s4, $s5, $s6);
$stmt->execute();
$stmt->close();
header("Location: ".$_SERVER['PHP_SELF']);
exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Robot Arm Control Panel</title>
    <style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f2f2f2; }
    h2 { margin-bottom: 15px; color: #333; }
.panel { background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px; }
.slider-container { margin: 10px 0; }
    input[type=range] { width: 700px; }
    button { padding: 7px 15px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; background: #666; color: #fff; }
    button:hover { background: #444; }
    table { border-collapse: collapse; width: 90%; margin-left: 30px; background: #fff; border-radius: 10px; overflow: hidden; }
    table, th, td { border: 1px solid #ccc; }
    th { background: #666; color: #fff; }
    td { padding: 10px; color: #333; }
    tr:nth-child(even) { background: #f9f9f9; }
    </style>
</head>
<body>

<h2>Robot Arm Control Panel</h2>
<form method="POST" id="controlForm">
    <?php for ($i=1;$i<=6;$i++): ?>
    <div class="slider-container">
    Servo <?php echo $i; ?>:
    <input type="range" min="0" max="180" value="90" name="servo<?php echo $i; ?>" id="servo<?php echo $i; ?>" oninput="updateLabel(<?php echo $i; ?>)">
    <span id="label<?php echo $i; ?>">90</span>
    </div>
    <?php endfor; ?>

    <button type="button" onclick="resetSliders()">Reset</button>
    <button type="submit" name="save">Save Pose</button>
    <button type="submit" name="run">Run</button>
</form>

<h2>Saved Poses</h2>
<table>
    <tr>
<th>#</th>
<th>Servo1</th>
<th>Servo2</th>
<th>Servo3</th>
<th>Servo4</th>
<th>Servo5</th>
<th>Servo6</th>
<th>Action</th>
    </tr>

<?php
    $result = $conn->query("SELECT * FROM pose WHERE status=1");
    while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>{$row['id']}</td>
    <td>{$row['servo1']}</td>
    <td>{$row['servo2']}</td>
    <td>{$row['servo3']}</td>
    <td>{$row['servo4']}</td>
    <td>{$row['servo5']}</td>
    <td>{$row['servo6']}</td>";
    echo "<td>
    <button type='button' onclick='loadPose(".json_encode($row).")'>Load</button>
    <form method='POST' style='display:inline'>
    <input type='hidden' name='id' value='{$row['id']}'>
    <button type='submit' name='remove'>Remove</button>
    </form>
    </td>";
    echo "</tr>";
    }
    ?>
</table>

<script>
// تحديث قيمة النص بجانب كل سلايدر
function updateLabel(servo) {
document.getElementById("label"+servo).innerText = document.getElementById("servo"+servo).value;
}

// اعادة تعيين جميع السلايدرات الى 90
function resetSliders() {
    for (let i=1; i<=6; i++) {
    document.getElementById("servo"+i).value = 90;
    updateLabel(i);
    }
}
// تحميل وضعية مسجلة الى الخطوط العرضية
function loadPose(pose) {
    for (let i=1; i<=6; i++) {
    document.getElementById("servo"+i).value = pose["servo"+i];
    updateLabel(i);
    }
}
</script>

</body>
</html>